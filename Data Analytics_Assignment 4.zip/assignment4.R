## load dataset
> Titanic=read.csv("https://kaggle2.blob.core.windows.net/competitions-data/kaggle/3136/train.csv?sv=2012-02-12&se=2015-10-22T17%3A08%3A57Z&sr=b&sp=r&sig=2YFNUbXvJWJmmx%2BFIWvLHKFb99KC22Y0AzvytrUyMwM%3D",header = TRUE,sep = ",")
> View(Titanic)
## remove missing data
> Titanic<-na.omit(Titanic)

## import package "gglpt2"
> library(ggplot2)

## generate boxplot
> ggplot(Titanic,aes(Pclass,Fare))+geom_boxplot()

## generate histogram
> Titanic$Survived=as.factor(Titanic$Survived)
> ggplot(Titanic,aes(x=Survived))+geom_histogram(binwidth=2)
> Titanic$Pclass=as.factor(Titanic$Pclass)
> ggplot(Titanic,aes(x=Pclass))+geom_histogram(binwidth=1)

## generate facet grid
> ggplot(Titanic, aes(x=Survived,fill=Pclass))+geom_histogram(binwidth=1)+facet_grid(Pclass ~.)

## generate violin plot
> ggplot(Titanic,aes(Pclass,Age))+geom_violin()

## generate heatmap
> install.packages("plyr")
> library(plyr)
## remove insignificant variables: passenger id, cabin, ticket, embarked
> newdata=Titanic[,-c(1,9,11,12)]
> View(newdata)
## set sex from "female","male" to "0","1"
> Sex=mapvalues(newdata$Sex, from=c('female','male'), to=c(0,1))
## regard passengers' name as table's row name
> row.names(newdata)=newdata$Name
> newdata=newdata[,-3]
> newdata=newdata[1:50,]
> data_matrix=data.matrix(data)
> data_heatmap <- heatmap(data_matrix, Rowv=NA, Colv=NA, col = cm.colors(256), scale="column", margins=c(5,10))